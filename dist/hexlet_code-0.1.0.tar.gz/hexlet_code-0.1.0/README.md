### Hexlet tests and linter status:
[![Actions Status](https://github.com/popperony/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/popperony/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/6fa0813e452af4b82a20/maintainability)](https://codeclimate.com/github/popperony/python-project-49/maintainability)


### Brain Even demo
[![asciicast](https://asciinema.org/a/9mumJihGGB57xu70dmYPvBlCs.svg)](https://asciinema.org/a/9mumJihGGB57xu70dmYPvBlCs)

### Brain Calc demo
[![asciicast](https://asciinema.org/a/x1SVcaol1TbDeFxc2QwthLrWR.svg)](https://asciinema.org/a/x1SVcaol1TbDeFxc2QwthLrWR)

### Brain GCD demo
[![asciicast](https://asciinema.org/a/yK3fhvaBJnxtz3shiOpMzeEWB.svg)](https://asciinema.org/a/yK3fhvaBJnxtz3shiOpMzeEWB)

### Brain progression demo
